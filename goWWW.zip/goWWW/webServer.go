package main

import (
	. "./unit"
	"fmt"
	"net/http"
	//"code.google.com/p/go.net/websocket"
	"log"
)

var db *Db

var sm *SessionManage

func main() {
	db = new(Db)
	db.Open("mysql", "caoping:1979420@/caoping?charset=utf8")
	/*user:=new(User)
	user.Db=db
	user.Login(LoginParam{Id:2})
	fmt.Printf("user:\n%+v\n",user)*/
	sm = &SessionManage{Db:db}
	sm.Init()

	http.Handle("/", http.FileServer(http.Dir("www"))) // <-- note this line
	http.HandleFunc("/user", userFunc) // <-- 用户
	http.HandleFunc("/wxs", wxServer) // <-- note this line
	http.HandleFunc("/data", dataFunc) // <-- 数据
	http.HandleFunc("/data/", dataFunc) // <-- 数据
	//http.Handle("/dataSocket", websocket.Handler(p.dataSocket))
	/*addrs:=p.getIpAddr();
	fmt.Printf("监听网址:%+v\n",addrs)
	fmt.Printf("端口号:%v\n",p.Socket)*/
	fmt.Printf("网站服务开启!\n")
	go func() {
		if err := http.ListenAndServe(":80", nil); err != nil {
			log.Fatal("开启遥网络端口失败:", err)
		}
	}()
	if err := http.ListenAndServeTLS(":443", "1_caoping.name_bundle.crt", "2_caoping.name.key", nil); err != nil {
		log.Fatal("开启遥网络端口失败:", err)
	}
}

func userFunc(response http.ResponseWriter, request *http.Request) {
	readCookie, err := request.Cookie("goSession")
	if err == nil {
		fmt.Printf("goSession:%+v\n", readCookie.Value)
	}

	cookie := &http.Cookie{}
	cookie.Name = "userName"
	cookie.Value = "caoping"

	fmt.Printf("%+v\n", cookie)
	//request.AddCookie(cookie)
	//http.SetCookie(response,cookie)
	response.Write([]byte("addCookie"))

}
func dataFunc(response http.ResponseWriter, request *http.Request) {
	msg := &Msg{}
	session := sm.CheckSession(response, request)
	fmt.Printf("session:%+v\n", session)
	request.ParseForm()
	msg.Cmd= request.PostForm.Get("cmd")
	if msg.Cmd == "" {
		msg.Msg = "未包含cmd指令!"
		response.Write([]byte(msg.String()))
		return
	}
	fmt.Printf("inData:%+v\n", request.PostForm)
	fmt.Printf("cmd:%s\n", msg.Cmd)
	switch msg.Cmd{
	case "login":
		session.User.Login(&request.PostForm, msg)
	case "regedit":
		session.User.Regedit(&request.PostForm, msg)
	case "project":

	default:

	}

	response.Write([]byte(msg.String()))
}

var WxToken = "caopingNameWWW20170407"

func wxServer(response http.ResponseWriter, request *http.Request) {
	//fmt.Println(request.URL.Path)        //request：http请求
	fmt.Printf("%+v\n", request)
	if v := request.FormValue("echostr"); v != "" {
		fmt.Printf("echo:%v\n", v)
		response.Write([]byte(v))
	}
}

func project(response *http.ResponseWriter,){

}