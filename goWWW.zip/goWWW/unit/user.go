package unit

import (
	"fmt"
	//"strconv"
	//"reflect"
	"net/url"
	"strconv"
)

type UserStatus int

const(
	UserNoLogin UserStatus =iota
	UserIsLogin
	UserIsLock
)

func (p UserStatus)String()string{
	switch p {
	case UserNoLogin:
		return "UserNoLogin"
	case UserIsLogin:
		return "UserIsLogin"
	case UserIsLock:
		return "UserIsLock"
	default:
		return "UserNoLogin"
	}
}

type User struct{
	Id int
	Name,NickName,DevId,Email,Phone string
	Db *Db
	Status UserStatus
}

type LoginParam struct{
	Id int
	Name,Password,Email,DevId string
}

func (p *User)Init(){
	p.Id=0
	p.Name="匿名"
	p.NickName="匿名"
	p.Status=UserNoLogin

}
//func (p *User)Regedit(param LoginParam){
func (p *User)Regedit(postForm *url.Values,msg *Msg){
	name:=postForm.Get("data[userName]")
	pw:=postForm.Get("data[passWord]")
	if name=="" || pw==""{
		msg.Msg = p.Status.String()
		return
	}
	param := LoginParam{
		Name:name,
		Password:pw}
	s:="INSERT INTO `user`(`name`, `password`, `email`) VALUES ('"+param.Name+"',"+param.Password+",'"+param.Email+"')"
	fmt.Printf("s: %v \n",s)
	r,e:=p.Db.Query(s)
	fmt.Printf("query:%+v\n",r)
	if e!=nil{
		fmt.Printf("query err:%+v\n",e)
		return
	}
	p.Name=param.Name
	p.Status=UserIsLogin
	msg.Msg = p.Status.String()
	if p.Status==UserIsLogin{
		msg.Data = p
	}
}
func (p *User)Login(postForm *url.Values,msg *Msg){
	name:=postForm.Get("data[userName]")
	pw:=postForm.Get("data[passWord]")
	if name=="" || pw==""{
		msg.Msg = "用户名或者密码为空!"
		return
	}
	s:="SELECT * FROM `user` WHERE `name`='"+name+"' AND `password`='"+pw+"'"
	r,e:=p.Db.GetOne(s)

	if e!=nil{
		fmt.Printf("login err:%+v\n",e)
		msg.Msg = "用户名或者密码错误!"
		return
	}
	loginCount,_:=strconv.Atoi(r["loginCount"])
	loginCount++
	/*t:=time.Now().Unix()
	s="UPDATE `user` SET `loginCount`="+strconv.Itoa(loginCount)+" AND `loginTime`="+strconv.Itoa(int(t))+" WHERE `id`='"+r["id"]+"'"*/
	s="UPDATE `user` SET `loginCount`="+strconv.Itoa(loginCount)+" WHERE `id`='"+r["id"]+"'"
	_,e=p.Db.Query(s)
	if e!=nil{
		fmt.Printf("更新登录数失败!:%+v\n",e)
	}
	p.Name=r["name"]
	p.NickName=r["NickName"]
	p.Status=UserIsLogin
	msg.Msg=p.Status.String()
	msg.Data=struct{Name,NickName string}{p.Name,p.NickName}
	fmt.Printf("%s 登录\n",p.Name)

}
