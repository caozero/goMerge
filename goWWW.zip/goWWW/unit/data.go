package unit

import "encoding/json"

type Msg struct {
	Cmd string `json:"cmd"`
	Msg string `json:"msg"`
	Data interface{} `json:"data"`
}

func (p *Msg)String()string{
	s,err:=json.Marshal(p)
	if err==nil{
		return string(s)
	}
	return "{msg:\"格式化数据错误!\"}"
}