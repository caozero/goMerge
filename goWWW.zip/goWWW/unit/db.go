package unit

import (
	_ "github.com/go-sql-driver/mysql"
	"database/sql"
	"fmt"
)

type Db struct {
	db *sql.DB
}

func (t *Db)Open(dbStr,connStr string) {
	db, err := sql.Open(dbStr,connStr)
	checkErr(err)
	t.db = db
}

func (t *Db)GetOne(qstr string) (row map[string]string,err error) {
	//查询数据
	rows, err := t.db.Query(qstr)
	checkErr(err)
	column, _ := rows.Columns()
	values := make([][]byte, len(column))     //values是每个列的值，这里获取到byte里
	scans := make([]interface{}, len(column)) //因为每次查询出来的列是不定长的，用len(column)定住当次查询的长度
	for i := range values {
		scans[i] = &values[i]
	}
	rows.Next()
	if err := rows.Scan(scans...); err != nil {
		fmt.Println(err)
		return row,err
	}
	row = make(map[string]string) //每行数据
	for k, v := range values {
		//每行数据是放在values里面，现在把它挪到row里
		key := column[k]
		row[key] = string(v)
	}
	return row,err
}

func (t *Db)GetAll(qstr string) (results map[int]map[string]string) {
	//查询数据
	rows, err := t.db.Query(qstr)
	checkErr(err)
	column, _ := rows.Columns()
	values := make([][]byte, len(column))     //values是每个列的值，这里获取到byte里
	scans := make([]interface{}, len(column)) //因为每次查询出来的列是不定长的，用len(column)定住当次查询的长度
	for i := range values {
		//让每一行数据都填充到[][]byte里面
		scans[i] = &values[i]
	}
	results = make(map[int]map[string]string) //最后得到的map
	i := 0
	for rows.Next() {
		//循环，让游标往下移动
		if err := rows.Scan(scans...); err != nil {
			//query.Scan查询出来的不定长值放到scans[i] = &values[i],也就是每行都放在values里
			fmt.Println(err)
			return
		}
		row := make(map[string]string) //每行数据
		for k, v := range values {
			//每行数据是放在values里面，现在把它挪到row里
			key := column[k]
			row[key] = string(v)
		}
		results[i] = row //装入结果集中
		i++
	}
	return results
}

func checkErr(err error) {
	if err != nil {
		panic(err)
	}
}


func (p *Db)Query(qstr string) (*sql.Rows,error) {
	return p.db.Query(qstr)
}