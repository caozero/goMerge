package unit

import (
	"crypto/md5"
	"time"
	"math/rand"
	"strconv"
	"encoding/hex"
	"net/http"
	"fmt"
)

/*
* 会话管理器
*/
type SessionManage struct {
	Db	*Db
	List	map[string]*Session
}

func (p *SessionManage)Init()*SessionManage{
	p.List=map[string]*Session{}
	return p
}
func (p *SessionManage)Len()int{
	return len(p.List)
}
func (p *SessionManage)Add()(session *Session){
	session=&Session{Db:p.Db}
	session.Init()
	p.List[session.Session]=session
	return session
}


func (p *SessionManage)CheckSession(response http.ResponseWriter, request *http.Request)(session *Session) {
	sessionStr,err:=request.Cookie("goSession")
	if err==nil{
		s,ok:=p.List[sessionStr.Value]
		if !ok{
			session=p.Add()
			cookie:=&http.Cookie{}
			cookie.Name="goSession"
			cookie.Value=session.Session
			cookie.HttpOnly=true
			http.SetCookie(response,cookie)
			fmt.Printf("cookie无对应数据,建立新会话\n")
		}else{
			session=s
			fmt.Printf("获取到会话\n")
		}
	}else{
		session=p.Add()
		cookie:=&http.Cookie{}
		cookie.Name="goSession"
		cookie.Value=session.Session
		cookie.HttpOnly=true
		http.SetCookie(response,cookie)
		fmt.Printf("没有cookie,建立新会话\n")
	}
	return session
}

/*
会话
*/
type Session struct {
	Session string
	User	*User
	StartTime time.Time
	Db	*Db
}

func (p *Session)Init(){
	p.StartTime=time.Now()
	n1:=strconv.Itoa(rand.Intn(99))
	n2:=strconv.Itoa(rand.Intn(99))
	md:=md5.Sum([]byte(strconv.Itoa(int(p.StartTime.UnixNano()))+n1+"_"+n2))
	//fmt.Printf("md:%v\n",hex.EncodeToString(md[:]))
	//fmt.Printf("time:%s\n",int(p.StartTime.UnixNano()))
	p.Session=hex.EncodeToString(md[:])
	p.User=&User{Db:p.Db}
	p.User.Init()
}