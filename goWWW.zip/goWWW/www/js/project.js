/**
 * Created by caoping on 2017/8/10.
 */

$(function () {
    $('body').on('click','.createProject',function () {
        var _t=$(this);

        if (_t.hasClass('createProject')){
            var box=_t.parents('section');
            __.sendCreateProject(box);
        }
        return false;
    })
    
})

__.sendCreateProject=function (p) {
    var box=p;
    var d={};
    d.cmd = 'project';
    d.cmd2 = 'createProject';
    d.title=box.find('input[name=title]').val();
    d.status=box.find('select[name=status]').val();
    d.title=box.find('textarea[name=note]').val();
    console.dir(d);
    __.net.send(d);
}
