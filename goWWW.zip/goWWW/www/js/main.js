/**
 * Created by caoping on 2017/6/28.
 */

__ = {};

__.c = {};
__.resetSize = function () {
    __.c.width = window.innerWidth;
    __.c.height = window.innerHeight;
    __.c.offsetX = __.c.width / -2;
    __.c.offsetY = __.c.height / -2;
};

__.bindEvent = function () {
    window.onresize = function () {
        __.resetSize();
    }
};

__.Window = function () {
    this.width = 480;
    this.height = 320;
    this.x = 0;
    this.y = 0;
    this.title = '窗口';
    for (var i in arguments[0]) {
        this[i] = arguments[0][i]
    }
    this.init = function () {
        this.makeEl();
        this.setStyle();
    };
    this.makeEl = function () {
        this.el = $('<section class="window"><h1 class="windowH1">窗口标题</h1>\
        <div class="cmdBar">\
          </div>\
          <div class="contentBox"></div>\
          </section>');
        this.titleEl = this.el.find('h1').first();
        this.contentBox = this.el.find('.contentBox').first();
        if (this.title)this.titleEl.text(this.title);
        $('body').append(this.el);
    };
    this.setContent = function (p) {
        this.contentBox.append(p);
    };
    this.setStyle = function () {
        this.offsetX = this.width / -2;
        this.offsetY = this.height / -2;
        var css = {};
        if (this.width)css.width = this.width / 100 + 'rem';
        if (this.height)css.height = this.height / 100 + 'rem';
        var x = (this.x + this.offsetX) - __.c.offsetX;
        css.left = x + 'px';
        var y = (-this.y + this.offsetY) - __.c.offsetY;
        css.top = y + 'px';
        this.el.css(css);
    };
    this.init();
};

__.init = function () {
    __.resetSize();
    //this.window = new this.Window({title: '测试窗口', width: 720, y: 200});
    //__.tpl=new __.TPL();

    __.rount.addEvent('login', __);
    var data = {cmd: 'login', data: {}};
    //__.net.send(data);
};

__.showLogin = function () {
    this.Wlogin = new __.Window({title: '注册', y: -200});
    var c = $('<div class="loginEl">\
        <p><input name="userName" placeholder="账号" value="caoping"></p>\
        <p><input type="password" name="password" placeholder="密码" value="1979420"></p>\
        <p><button class="login">登录</button></p>\
        </div>');
    this.Wlogin.setContent(c);
    this.Wlogin.el.find('.loginEl').on('click', '.login', function () {
        var _t = $(this);
        var _p = _t.parents('.contentBox');
        if (_t.hasClass('login')) {
            var d = {
                userName: _p.find('input[name=userName]').val()
                , passWord: _p.find('input[name=password]').val()
            };
            __.net.send({cmd:'login',data:d});
        }
    });
};
__.showRegedit = function () {
    this.Wregedit = new __.Window({title: '注册', y: -200});
    var c = $('<div class="regeditEl">\
        <p><input name="userName" placeholder="账号" value="caoping"></p>\
        <p><input type="email" name="email" placeholder="邮箱" value="caoping@163.com"></p>\
        <p><input type="password" name="password" placeholder="密码" value="1979420"></p>\
        <p><button class="regeditNewUser">注册</button></p>\
        </div>');
    this.Wregedit.setContent(c);
    this.Wregedit.el.find('.regeditEl').on('click', '.regeditNewUser', function () {
        var _t = $(this);
        var _p = _t.parents('.regeditEl');
        if (_t.hasClass('regeditNewUser')) {
            var d = {
                userName: _p.find('input[name=userName]').val()
                , email: _p.find('input[name=email]').val()
                , passWord: _p.find('input[name=password]').val()
            };
            __.net.send({cmd:'regedit',data:d});
        }
    });
    __.rount.addEvent('regedit', __);
};

__.login = function (p) {
    console.dir(p);
    switch(p.msg){
        case "UserNoLogin":
        default:
            __.showLogin();
            break;
    }
};
__.regedit = function (p) {
    console.dir(p);
};

__.rount = {
    list: []
    , eventList: {}
    , densityTime: 3000
    , getTime: 0
    , enableServerMsg: false
    , url: '/data'
    , init: function () {
        this.bindKeyEvent();
    }
    , bindKeyEvent: function () {
        $(window).on('keyup', function () {
            switch (event.keyCode) {
                case    82:
                    break;
            }
        })
    }
    , reloadBrowser: function (p) {
        var url = 'data' in p && 'url' in p.data ? p.data.url : location.href;
        location.href = url;
    }
    , getCmd: function (p) {
        var a = [];
        for (var i in p) {
            a.push(p[i]);
        }
        this.addMsg(a);
    }
    , addEvent: function (name, obj) {
        this.eventList[name] = obj;
    }
    , delEvent: function (name) {
        if (name in this.eventList)delete this.eventList[name];
    }
    , addMsg: function (p) {
        if (Array.isArray(p)) {
            this.list = this.list.concat(p);
        } else {
            this.list.push(p);
        }
        this.update();
        return;
    }
    , update: function () {
        while (1) {
            var p = this.list.shift();
            if (!p)break;
            var cmd = p['cmd'];
            if (cmd in this.eventList)this.eventList[cmd][cmd](p);
        }
    }
};


__.net = {
    url: '/data'
    , init: function () {

    }
    , send: function (d) {
        $.ajax({
            url: '/data'
            , data: d
            , type: 'post'
            , dataType: 'json'
            , success: function (d) {
                console.dir(d);
                __.rount.addMsg(d);
            }
            ,error:function (e) {
                console.dir(e);
            }
        })
    }
};

$(function () {
    __.init();
});