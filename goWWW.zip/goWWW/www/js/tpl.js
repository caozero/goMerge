/**
 * 模板
 * Created by caoping on 2017/6/29.
 */

__=__?__:{};

__.TPL=function () {
    var _this=this;
    this.tplBase={};
    for(var i in arguments){this[i]=arguments[0][i]}
    this.init=function () {
        this.read();
    };
    this.loadTpl=function (p) {
        var name=p.name;
        var url='/tpl/'+name+'.html';
        $.ajax({
            url:url
            ,success:function (d) {
                _this.addTpl(name,url,d);
                if('target' in p)_this.appendTo(p.target,_this.tplBase[name]);
            }
        })
    };
    this.addTpl=function (name,url,source) {
        this.tplBase[name]={
            name:name,url:url,source:source
        };
    };
    this.read=function (p) {
        var el=p===undefined?$('body'):p;
        el.find('[tpl-include]').each(function () {
            console.dir(this);
            var _t=$(this);
            var name=_t.attr('tpl-include');
            if(name in _this.tplBase){
                _this.appendTo(_t,_this.tplBase[name]);
                return;
            }
            _this.loadTpl({name:name,target:_t})
        });
        el.find('[tpl-src]').each(function () {
            var _t=$(this);
            var dataUrl=_t.attr('tpl-src');
            _this.loadData(_t,dataUrl);
        });
        return this;
    };
    this.appendTo=function (target,tpl) {
        var _t=target;
        _t.html(tpl.source);
        this.read(_t);
    };
    this.loadData=function (target,url) {
        $.ajax({
            url:url
            ,success:function (d) {
                try{
                    d=typeof d=='string'?JSON.parse(d):d;
                    _this.write(target,d);
                }catch(e){

                }

            }
        })
    };
    this.write=function (target,data) {
        //var _t=target;
        target.find('[tpl-list]').each(function () {
            var _t=$(this);
            var dataName=_t.attr('tpl-list');
            var block=_this.parseHtmlText(_this.getHtmlText(_t.find('[tpl-block]').remove()));
            //var num=block.attr('tpl-block');
            var list=data[dataName];
            for(var i in list){
                var a=list[i];
                var b=block.slice(0);
                for(var n in b){
                    var str=b[n];
                    if(str[0]=='.'){
                        b[n]='{'+str.substr(1,str.length)+'}';
                        continue;
                    }
                    if(str in a){
                        b[n]=a[str];
                    }
                }
                _t.append(b.join(''));
            }
        });
        var arr=this.parseHtmlText(target.html());
        for(var i in arr){
            var str=arr[i];
            if(str in data){
                arr[i]=data[str];
            }
        }
        target.html(arr.join(''));
        //target.remove();
    };
    this.getHtmlText=function (block) {
        var p=$('<div>');
        p.append(block);
        var str=p.html();
        return str;
    };
    this.parseHtmlText=function (str) {
        var arr=str.split(/[\{\}]/);
        return arr;
    }
    this.init();
};
