var __ = __ ? __ : {};

__.Config = function () {
    this.width = this.height = 512;
    this.fillSpeed = 10;
    this.init = function () {

    };
    this.init();
};
__.start = function () {

    console.log('start!');
    this.c = new __.Config();
    this.width = this.c.width;
    this.height = this.c.height;
    this.inColor = {
        r: 0, g: 255, b: 255, a: 255
    }
    this.image = new Image();
    this.image.onload = () => {
        this.makeEl();
        this.setScale();
        this.bindEvent();
        //this.draw();
        //this.changeColor();
        this.loop();
    }
    this.image.src = 'res/image/t.jpg';
};

__.makeEl = function () {
    document.body.style.margin = 0;
    this.canvas = document.createElement('canvas');
    this.canvas.width = __.c.width;
    this.canvas.height = __.c.height;
    this.canvas.style.width = '100%';
    this.canvas.style['max-width'] = '100%';
    this.ctx = this.canvas.getContext('2d');
    document.body.appendChild(this.canvas);

    this.ctx.clearRect(0, 0, this.c.width, this.c.height);

    this.ctx.drawImage(this.image, 0, 0, this.width, this.height);

    this.imageData = this.ctx.getImageData(0, 0, this.c.width, this.c.height);
    this.data = this.imageData.data;
    for (let i in this.data) {
        if (this.data[i] < 128) this.data[i] = 0;
    }
};

__.setScale = function () {
    let ow = this.canvas.offsetWidth;
    let oh = this.canvas.offsetHeight;
    this.scaleX = this.width / ow;
    this.scaleY = this.height / oh;
}

__.setPix = function ({x = 0, y = 0}) {
    this.inColor = {
        r: Math.random() * 255 | 0
        , g: Math.random() * 255 | 0
        , b: Math.random() * 255 | 0
        , a: 255
    };
    let d = this.data;
    let r = (y * this.width + x) * 4 | 0;
    d[r] = this.inColor.r;
    d[r + 1] = this.inColor.g;
    d[r + 2] = this.inColor.b;
    d[r + 3] = this.inColor.a;
};
__.draw = function () {
    //this.ctx.clearRect(0, 0, this.c.width, this.c.height);
    let c = this.inColor;
    let r = c.r.toString(16);
    r = r.length == 1 ? '0' + r : r;
    let g = c.g.toString(16);
    g = g.length == 1 ? '0' + g : g;
    let b = c.b.toString(16);
    b = b.length == 1 ? '0' + b : b;
    this.ctx.fillStyle = `#` + r + g + b;
    //this.ctx.fillRect(this.c.width/2|0,this.c.height/2|0,1,1);
    this.ctx.fillRect(0, 0, 1, 1);


};

__.loop = function () {
    //requestAnimationFrame(() => this.loop());
    setTimeout(() => {
        this.loop();
    },33);
    __.update();


};

__.update = function () {
    //let data=this.ctx.getImageData(0,0,this.c.width,this.c.height);
    let d = this.data;
    let w = __.c.width;
    let h = __.c.height;
    let row = w * 4;
    let l = max = d.length - 4;
    let i = 0;
    let c = this.inColor;
    let fillSpeed = __.c.fillSpeed;
    while (i <= l) {
        //i+=4;
        let r = i;
        let g = i + 1;
        let b = i + 2;
        let a = i + 3;
        let index = i / 4;
        i += 4;
        if (d[r] === 0 && d[g] === 0 && d[b] === 0 && d[a] === 255) continue;
        if (Math.abs(d[r] - c.r) < 5 && Math.abs(d[g] - c.g) < 5 && Math.abs(d[b] - c.b) < 5) {
            if (d[a] < 255) {
                d[a] += fillSpeed;
            }
            continue;
        }

        if (index % w != 0) if (this.checkColor({r: r, g: g, b: b, a: a, d: d, p: 4})) continue;
        if ((index + 1) % w != 0) if (this.checkColor({r: r, g: g, b: b, a: a, d: d, p: -4})) continue;
        if (this.checkColor({r: r, g: g, b: b, a: a, d: d, p: row})) continue;
        if (this.checkColor({r: r, g: g, b: b, a: a, d: d, p: -row})) continue;
    }
    this.ctx.putImageData(this.imageData, 0, 0);
    //console.dir(data);
};

__.checkColor = function ({r, g, b, a, p, d}) {
    //if((a+p)<0 ||(a+p)>this.imageData.length) return false;

    let c = this.inColor;

    //if(d[a+p]>1){
    let pr = d[r + p];
    let pg = d[g + p];
    let pb = d[b + p];
    let pa = d[a + p];
    if (pr === 0 && pg === 0 && pb === 0 && pa === 255) return false;
    if (pa > 1 && (pr === c.r && pg === c.g && pb === c.b)) {
        //if((Math.abs(d[r+p]-c.r)<5 && Math.abs(d[g+p]-c.g)<5 && Math.abs(d[b+p]-c.b)<5)){
        d[r] = c.r;
        d[g] = c.g;
        d[b] = c.b;
        d[a] = 1;
        return true;
    }
    return false;
}

__.changeColor = function () {
    this.inColor = {
        r: Math.random() * 255 | 0
        , g: Math.random() * 255 | 0
        , b: Math.random() * 255 | 0
        , a: 255
    };
    this.setPix({x: Math.random() * __.c.width | 0, y: Math.random() * __.c.height | 0});

}

__.Reader = function () {
    this.offset = 0;
    this.buffer = null;
    this.r = 0;
    this.g = 0;
    this.b = 0;
    this.a = 0;
    for (let i in arguments[0]) {
        this[i] = arguments[0][i];
    }
    this.init = function () {

    }
    this.read = function (p) {
        this.offset = p;
        this.r = this.buffer[this.offset];
        this.g = this.buffer[this.offset + 1];
        this.b = this.buffer[this.offset + 2];
        this.a = this.buffer[this.offset + 3];
    }
    this.init();
};

__.bindEvent = function () {
    //this.clickEvent='touchstart' in window?'touchstart'
    this.canvas.addEventListener('click', (e) => {
        console.dir(e);
        let x = e.offsetX * this.scaleX | 0;
        let y = e.offsetY * this.scaleY | 0;
        this.setPix({x: x, y: y});
        console.log(x, ' ', y);

    });
}

$(function () {
    __.start();
});